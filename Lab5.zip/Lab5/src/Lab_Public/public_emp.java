package Lab_Public;

public class public_emp
{
	public float saraly = 15000.0f;
	public float ot(int h,int bath)
	{
		return h*bath;
	}

}
