
public class Lab1 {

	public static void main(String[] args) {
		System.out.println("Name  : Ketsaraporn Puengphuk");
		System.out.println("ID    : 0029185");
		System.out.println("Email : aboriginehipster@gmail.com");
		System.out.println("Age   : 24 year");
		System.out.println("Phone : 094-331-4970");
		System.out.println("Major : Computer Programmer");

	}

}
