
public class Box2 {
	public int x,z;
	public void multiply()
	{
		for(int i=1;i<12;i++)
		{
			z=x*i;
			System.out.println(x+"*"+i+"="+z);
		}
	}

}
