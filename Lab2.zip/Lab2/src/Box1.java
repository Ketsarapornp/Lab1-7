
public class Box1 {


	public double w,h,d;
	public double volumn()
	{
		return w*h*d;
	}
	public double triangle()
	{
		return (0.5)*w*h;
	}

}
