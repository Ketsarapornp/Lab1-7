
public class Main
{

	public static void main(String[] args)
	{
		cal c = new cal();
		c.Mul();
		c.add(2, 5);
		System.out.println("Even = "+c.OddEven());
		System.out.println("Grade = "+c.Grade(10, 10, 10, 10));

	}

}
