
public class Main
{

	public static void main(String[] args)
	{
		int age = 24;
		double gpa=3.00;
		String name="Ketsaraqporn Puengphuk";
		char gender='F';
		
		System.out.println("This is programming");
		System.out.println("Name : "+ name+ "\nAge : "+age+"\nGender : "+ gender +"\ngpa : "+gpa);

	}

}
