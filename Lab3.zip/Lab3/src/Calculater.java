
public class Calculater
{

	public double a, b, c;
	int x,y,z;

	public double square(double w, double h)
	{
		return w * h;
	}
	
	public void multiply()
	{
		y=5;
		for(x=1;x<=12;x++)
		{
			z=y*x;
			System.out.println(y+" * "+x+" = "+z);
		}
	}

}
